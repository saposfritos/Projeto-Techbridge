<h1>Erro 404</h1>
<p>Algo deu errado no cadastro!</p>
<a href="cadastro.php">Voltar à página inicial</a>